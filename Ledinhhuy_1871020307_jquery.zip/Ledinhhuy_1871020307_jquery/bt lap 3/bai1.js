document.getElementById("addJobBtn").addEventListener("click", function() {
    let jobText = document.getElementById('jobInput').value.trim();
    if (jobText !== "") {
        let li = document.createElement('li');
        li.textContent = jobText;
        li.classList.add("job-item");

        // Toggle trạng thái hoàn thành
        li.addEventListener("click", function() {
            this.classList.toggle('completed');
        });

        // Nút xóa
        let deleteBtn = document.createElement('button');
        deleteBtn.textContent = "Xóa";
        deleteBtn.classList.add("deleteBtn");
        deleteBtn.addEventListener("click", function(event) {
            event.stopPropagation();
            li.remove();
        });

        li.appendChild(deleteBtn);
        document.getElementById('jobList').appendChild(li);
        document.getElementById('jobInput').value = "";
    }
});