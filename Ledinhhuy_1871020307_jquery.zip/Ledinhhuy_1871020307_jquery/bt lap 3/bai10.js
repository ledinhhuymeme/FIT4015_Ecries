$(document).ready(function() {
    $("#getWeather").click(function() {
        let city = $("#cityInput").val().trim();
        let apiKey = "YOUR_API_KEY"; // Thay bằng API Key của bạn
        let apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=vi`;

        if (city === "") {
            $("#weatherResult").html("<p style='color: red;'>Vui lòng nhập tên thành phố!</p>");
            return;
        }

        $.ajax({
            url: apiUrl,
            method: "GET",
            success: function(data) {
                let temp = data.main.temp;
                let weather = data.weather[0].description;
                let cityName = data.name;

                $("#weatherResult").html(`
                    <p><strong>${cityName}</strong></p>
                    <p>Nhiệt độ: ${temp}°C</p>
                    <p>Thời tiết: ${weather}</p>
                `);
            },
            error: function() {
                $("#weatherResult").html("<p style='color: red;'>Không tìm thấy thành phố!</p>");
            }
        });
    });
});