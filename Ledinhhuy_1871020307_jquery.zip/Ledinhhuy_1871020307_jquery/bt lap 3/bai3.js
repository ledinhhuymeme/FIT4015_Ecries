$(document).ready(function() {
    $("#registrationForm").submit(function(event) {
        let isValid = true;
        $(".error").text(""); // Xóa thông báo lỗi cũ

        let name = $("#name").val().trim();
        let email = $("#email").val().trim();
        let password = $("#password").val().trim();
        
        if (name === "") {
            $("#nameError").text("Tên không được để trống.");
            isValid = false;
        }
        
        let emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            $("#emailError").text("Email không hợp lệ.");
            isValid = false;
        }
        
        if (password.length < 6) {
            $("#passwordError").text("Mật khẩu phải có ít nhất 6 ký tự.");
            isValid = false;
        }
        
        if (!isValid) {
            event.preventDefault(); // Ngăn chặn gửi biểu mẫu nếu có lỗi
        }
    });
});