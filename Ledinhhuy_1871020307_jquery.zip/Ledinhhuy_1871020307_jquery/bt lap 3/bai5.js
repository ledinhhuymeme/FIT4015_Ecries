const secondsInput = document.getElementById("seconds");
const startButton = document.getElementById("start");
const timerDisplay = document.getElementById("timer");

let countdownInterval;

startButton.addEventListener("click", () => {
    let seconds = parseInt(secondsInput.value);
    if (isNaN(seconds) || seconds <= 0) {
        alert("Vui lòng nhập một số giây hợp lệ.");
        return;
    }
    startButton.disabled = true;
    secondsInput.disabled = true;
    timerDisplay.textContent = seconds;

    // Bắt đầu đếm ngược
    countdownInterval = setInterval(() => {
        seconds--;

        if (seconds < 0) {
            clearInterval(countdownInterval);
            timerDisplay.textContent = "Hết giờ!";
            startButton.disabled = false; // Bật lại nút Bắt đầu
            secondsInput.disabled = false; // Bật lại đầu vào
        } else {
            timerDisplay.textContent = seconds;
        }
    }, 1000);
});